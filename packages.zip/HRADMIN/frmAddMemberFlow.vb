﻿Public Class frmAddMemberFlow
    Private strQ As String
    Private Sub frmAddMemberFlow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ClsGetData = New Cls_GetData
        SetAllConnectionDB()
        ClsUpdateData = New Cls_UpdateData
        strQ = ""
        strQ = strQ & "  select * "
        strQ = strQ & "  from flow "
        ClsGetData.GetFlow(Connection, Me.cbbFlow, strQ)
    End Sub

    Private Sub cmbOk_Click(sender As Object, e As EventArgs) Handles cmbOk.Click
        frmMember.GridMembers.Rows(ClsClickCurrentGridView.Row).Cells(9).Value = Me.cbbFlow.Text
        Me.Close()
    End Sub
End Class