﻿Imports MySql.Data.MySqlClient
Public Class Cls_Insert
    Private sqlCommand As MySqlCommand
    Public Sub Insert(iConnection As MySqlConnection, strQ As String)
        'strQ = "delete from email_for_alert where PC_EMAIL = '" & Email & "'"

        CheckConnection(iConnection)
        sqlCommand = New MySqlCommand(strQ, iConnection)
        sqlCommand.ExecuteNonQuery()
        iConnection.Close()
        iConnection = Nothing

    End Sub


    Public Sub ExecuteTransaction(iConnection As MySqlConnection, queries As List(Of String))
        CheckConnection(iConnection)

        Using transaction As MySqlTransaction = iConnection.BeginTransaction()
            Try
                For Each strQ As String In queries
                    Using sqlCommand As New MySqlCommand(strQ, iConnection, transaction)
                        sqlCommand.ExecuteNonQuery()
                    End Using
                Next

                ' Commit Transaction
                transaction.Commit()
                ' MessageBox.Show("Transaction สำเร็จ")

            Catch ex As Exception
                ' Rollback Transaction ถ้าเกิดข้อผิดพลาด
                transaction.Rollback()
                MessageBox.Show("Transaction ล้มเหลว: " & ex.Message)

            Finally
                If iConnection.State = ConnectionState.Open Then
                    iConnection.Close()
                End If
                iConnection = Nothing
            End Try
        End Using
    End Sub

End Class
