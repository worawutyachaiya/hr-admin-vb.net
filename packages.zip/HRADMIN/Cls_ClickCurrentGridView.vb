﻿Public Class Cls_ClickCurrentGridView
    Public Row As Integer = 0

    Public Sub ClickGridview(ByRef GridMembers As DataGridView)
        If Row < 0 Then Row = 0
        GridMembers.Rows(Row).Selected = True
        GridMembers.FirstDisplayedScrollingRowIndex = Row

    End Sub

End Class
